from build123d import *
from ocp_vscode import show
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.StlAPI import StlAPI_Writer, StlAPI_Reader
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.TopoDS import TopoDS_Shape
import os

# ✅ UPDATED PATH
step_path = "/Users/softage/Desktop/RedoxWirelessRev1TopLeft.step"
stl_path = "/Users/softage/Desktop/output_RedoxWirelessRev1TopLeft.stl"

if not os.path.exists(step_path):
    raise FileNotFoundError(step_path)

print("Importing STEP... (wait)")

part = import_step(step_path)
shape = part.wrapped

# ---------------- VOLUME STEP ----------------
props_step = GProp_GProps()
BRepGProp.VolumeProperties_s(shape, props_step)
step_volume = props_step.Mass()

print("STEP Volume:", step_volume)

# ---------------- MESH + STL ----------------
print("Meshing...")
mesh = BRepMesh_IncrementalMesh(shape, 1.5)  # faster
mesh.Perform()

print("Writing STL...")
writer = StlAPI_Writer()
writer.ASCIIMode = True
writer.Write(shape, stl_path)

print("STL Exported:", stl_path)

# ---------------- STL LOAD ----------------
stl_shape = TopoDS_Shape()
reader = StlAPI_Reader()
reader.Read(stl_shape, stl_path)

# ---------------- VOLUME STL ----------------
props_stl = GProp_GProps()
BRepGProp.VolumeProperties_s(stl_shape, props_stl)
stl_volume = props_stl.Mass()

print("STL Volume:", stl_volume)

# ---------------- DIFFERENCE ----------------
diff = abs(step_volume - stl_volume)
percent_diff = (diff / step_volume) * 100

print("Percent Difference:", percent_diff, "%")

# ---------------- PREVIEW ----------------
print("Opening viewer...")

show(part)   # ⚠️ may take time / may hang