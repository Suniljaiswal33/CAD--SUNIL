from build123d import *

original = "/Users/softage/Desktop/RedoxWirelessRev1ReceiverTop.stl"
output = "/Users/softage/Desktop/RedoxWirelessRev1ReceiverTop_output.stl"


p1 = import_stl(original)
p2 = import_stl(output)


v1 = p1.volume
v2 = p2.volume


print("\nOriginal volume =", v1)
print("Output volume   =", v2)

diff = abs(v1 - v2)

print("Difference =", diff)

percent = diff / v1 * 100

print("Percent difference =", percent)