from build123d import *
from ocp_vscode import show


# =========================
# SCALE CONTROL
# =========================

scale = 1.00
# change this value to match volume
# example 0.95 / 0.92 / 1.03


# =========================
# ORIGINAL DIMENSIONS
# =========================

L0 = 400
W0 = 262
H0 = 140

extra0 = 20
wall0 = 20
half_wall0 = 10
bottom0 = 20

cut_w0 = 120
cut_h0 = 60

corner_cut0 = 85


# =========================
# SCALED DIMENSIONS
# =========================

L = L0 * scale
W = W0 * scale
H = H0 * scale

extra = extra0 * scale
wall = wall0 * scale
half_wall = half_wall0 * scale
bottom = bottom0 * scale

cut_w = cut_w0 * scale
cut_h = cut_h0 * scale

corner_cut = corner_cut0 * scale


part_name = "RedoxWirelessRev1ReceiverTop_output"


# =========================
# MODEL
# =========================

with BuildPart() as RedoxWirelessRev1ReceiverTop_output:

    # base
    Box(W, L, bottom)

    # walls

    with Locations((0, L/2 - wall/2, H/2)):
        Box(W, wall, H)

    with Locations((0, -L/2 + wall/2, H/2)):
        Box(W, wall, H)

    with Locations((-W/2 + wall/2, 0, H/2)):
        Box(wall, L, H)

    with Locations((W/2 - wall/2, 0, H/2)):
        Box(wall, L, H)


    # upper thin walls

    with Locations((0, -L/2 + half_wall/2, H + extra/2)):
        Box(W, half_wall, extra)

    with Locations((-W/2 + half_wall/2, 0, H + extra/2)):
        Box(half_wall, L, extra)

    with Locations((W/2 - half_wall/2, 0, H + extra/2)):
        Box(half_wall, L, extra)


    # front cut

    with Locations((0, -L/2, H/2)):
        Box(
            cut_w,
            wall + 1,
            cut_h,
            mode=Mode.SUBTRACT
        )


    # corner remove

    for sx in [-1, 1]:
        for sy in [-1, 1]:

            with Locations((sx*W/2, sy*L/2, H + extra/2)):
                Box(
                    corner_cut,
                    corner_cut,
                    extra + 2,
                    mode=Mode.SUBTRACT
                )


# =========================
# EXPORT
# =========================

path = "/Users/softage/Desktop/RedoxWirelessRev1ReceiverTop_output.stl"

export_stl(
    RedoxWirelessRev1ReceiverTop_output.part,
    path
)

print("Saved to:", path)


show(RedoxWirelessRev1ReceiverTop_output.part)