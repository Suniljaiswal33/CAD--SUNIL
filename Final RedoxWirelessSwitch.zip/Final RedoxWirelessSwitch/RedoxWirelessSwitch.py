from build123d import *
from pathlib import Path
import trimesh

from ocp_vscode import show

desktop = Path.home() / "Desktop"

step_path = desktop / "RedoxWirelessSwitch.step"
given_stl = desktop / "RedoxWirelessSwitch.stl"
output_stl = desktop / (step_path.stem + "_output.stl")

print("Loading STEP...")
part = import_step(step_path)

show(part)

print("Exporting STL...")
export_stl(part, output_stl)

print("Loading STL...")

mesh_given = trimesh.load_mesh(given_stl)
mesh_output = trimesh.load_mesh(output_stl)

# -------- SCALE FIX ----------
mesh_output.apply_scale(0.1)

v1 = mesh_given.volume
v2 = mesh_output.volume

print("Given:", v1)
print("Output:", v2)

diff = abs(v1 - v2)
ratio = diff / v1

print("Diff:", diff)
print("Ratio:", ratio)

print("BBox given :", mesh_given.bounding_box.extents)
print("BBox output:", mesh_output.bounding_box.extents)

if ratio < 0.001:
    print("OK ✅ Same geometry")
else:
    print("⚠️ mismatch")