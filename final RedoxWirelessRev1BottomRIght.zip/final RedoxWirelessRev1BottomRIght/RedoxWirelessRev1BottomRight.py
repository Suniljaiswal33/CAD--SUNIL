from build123d import *
from pathlib import Path
import trimesh

# viewer
from ocp_vscode import show

# -----------------------------
# Paths
# -----------------------------

desktop = Path.home() / "Desktop"

step_path = desktop / "RedoxWirelessRev1BottomRight.step"
stl_path = desktop / (step_path.stem + "_output.stl")

# -----------------------------
# Import STEP
# -----------------------------

part = import_step(step_path)

print("STEP loaded")

# -----------------------------
# Show in OCP viewer
# -----------------------------

show(part)

# -----------------------------
# Export STL
# -----------------------------

export_stl(part, stl_path)

print("STL saved:", stl_path)

# -----------------------------
# Volume check
# -----------------------------

step_volume = part.volume

mesh = trimesh.load_mesh(stl_path)
stl_volume = mesh.volume

print("STEP volume:", step_volume)
print("STL volume :", stl_volume)

diff = abs(step_volume - stl_volume)

print("Difference:", diff)