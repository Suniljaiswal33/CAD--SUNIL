from build123d import *
from pathlib import Path
import trimesh

from ocp_vscode import show

# -----------------------------
# Paths
# -----------------------------

desktop = Path.home() / "Desktop"

step_path = desktop / "redox keyboard assembly.step"

output_stl = desktop / (step_path.stem + "_output.stl")

print("Loading STEP assembly...")

asm = import_step(step_path)

print("STEP loaded")

# -----------------------------
# Preview
# -----------------------------

show(asm)

# -----------------------------
# STEP volume
# -----------------------------

step_volume = asm.volume

print("STEP volume:", step_volume)

# -----------------------------
# Export STL
# -----------------------------

print("Exporting STL...")

export_stl(asm, output_stl)

print("STL saved:", output_stl)

# -----------------------------
# Load STL
# -----------------------------

mesh = trimesh.load_mesh(output_stl)

stl_volume = mesh.volume

print("STL volume :", stl_volume)

# -----------------------------
# Difference check
# -----------------------------

diff = abs(step_volume - stl_volume)

ratio = diff / step_volume

print("Difference:", diff)
print("Ratio:", ratio)

# -----------------------------
# Bounding box check
# -----------------------------

bbox = mesh.bounding_box.extents

print("BBox:", bbox)

# -----------------------------
# Result
# -----------------------------

if ratio < 0.0001:
    print("✅ Volume OK")
else:
    print("⚠️ Volume mismatch")