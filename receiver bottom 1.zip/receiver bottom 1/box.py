from build123d import *

L = 120
W = 70
H = 50
wall = 3

with BuildPart() as p:

    with BuildSketch():
        Rectangle(L, W)
    extrude(amount=H)

    with BuildSketch(Plane.XY.offset(wall)):
        Rectangle(L-2*wall, W-2*wall)
    extrude(amount=H-wall, mode=Mode.SUBTRACT)

export_stl(p.part, "/Users/softage/Desktop/box_model.stl")

print("STL generated")