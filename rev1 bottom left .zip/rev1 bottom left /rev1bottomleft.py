from build123d import *
import os

# ======================
# dimensions
# ======================

length = 1730
width = 1397

thickness = 10
wall_offset = 80

corner_radius = 35

boss_d = 60
boss_h = 40
hole_d = 20

wall_height = 80
wall_thickness = 15


# ======================
# desktop path
# ======================

desktop = os.path.join(os.path.expanduser("~"), "Desktop")
file_path = os.path.join(desktop, "rev1bottomleft.stl")


# ======================
# model
# ======================

with BuildPart() as part:

    # -------- base plate --------
    with BuildSketch() as sk:
        RectangleRounded(length, width, corner_radius)

    extrude(amount=thickness)


    # -------- inner pocket --------
    with BuildSketch(Plane.XY.offset(thickness)) as sk2:
        RectangleRounded(
            length - wall_offset * 2,
            width - wall_offset * 2,
            corner_radius
        )

    extrude(amount=80, mode=Mode.SUBTRACT)


    # -------- bosses --------

    boss_pos = [
        (-length/2 + 120, -width/2 + 120),
        (length/2 - 120, -width/2 + 120),
        (-length/2 + 120, width/2 - 120),
        (length/2 - 120, width/2 - 120),
    ]

    for p in boss_pos:

        with Locations((p[0], p[1], thickness)):
            Cylinder(boss_d/2, boss_h)
            Hole(hole_d/2, depth=boss_h)


    # ======================
    # TOP WALL (NEW)
    # ======================

    with BuildSketch(Plane.XY.offset(thickness)) as sk3:

        RectangleRounded(length, width, corner_radius)

        RectangleRounded(
            length - 2 * wall_thickness,
            width - 2 * wall_thickness,
            corner_radius,
            mode=Mode.SUBTRACT,
        )

    extrude(amount=wall_height)


# ======================
# export
# ======================

export_stl(part.part, file_path)

print("STL saved:", file_path)