from build123d import *
from ocp_vscode import show
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.StlAPI import StlAPI_Writer, StlAPI_Reader
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.TopoDS import TopoDS_Shape
import os

# ---------------- FILE PATH ----------------
step_path = "/Users/softage/Desktop/RedoxWirelessRev1TopRight.step"

# auto output name
base = os.path.basename(step_path)
name = os.path.splitext(base)[0]
stl_path = f"/Users/softage/Desktop/output_{name}.stl"

# ---------------- CHECK ----------------
if not os.path.exists(step_path):
    raise FileNotFoundError(step_path)

print("Importing STEP (build123d)... (wait)")

# ---------------- IMPORT STEP ----------------
part = import_step(step_path)
shape = part.wrapped

# ---------------- STEP VOLUME ----------------
props_step = GProp_GProps()
BRepGProp.VolumeProperties_s(shape, props_step)
step_volume = props_step.Mass()

print("STEP Volume:", step_volume)

# ---------------- MESH ----------------
print("Meshing...")
mesh = BRepMesh_IncrementalMesh(shape, 0.5)  # good accuracy
mesh.Perform()

# ---------------- EXPORT STL ----------------
print("Writing STL...")
writer = StlAPI_Writer()
writer.ASCIIMode = True
writer.Write(shape, stl_path)

print("✅ STL created:", stl_path)

# ---------------- LOAD STL ----------------
print("Loading STL...")
stl_shape = TopoDS_Shape()
reader = StlAPI_Reader()
reader.Read(stl_shape, stl_path)

# ---------------- STL VOLUME ----------------
props_stl = GProp_GProps()
BRepGProp.VolumeProperties_s(stl_shape, props_stl)
stl_volume = props_stl.Mass()

print("STL Volume:", stl_volume)

# ---------------- DIFFERENCE ----------------
diff = abs(step_volume - stl_volume)
percent_diff = (diff / step_volume) * 100

print("Volume Difference:", diff)
print("Percent Difference:", percent_diff, "%")

# ---------------- VALIDATION ----------------
if percent_diff < 0.001:
    print("✅ Volumetric match (near-zero difference)")
else:
    print("⚠️ Not zero, increase mesh accuracy")

# ---------------- PREVIEW ----------------
print("Opening OCP Viewer...")
show(part)