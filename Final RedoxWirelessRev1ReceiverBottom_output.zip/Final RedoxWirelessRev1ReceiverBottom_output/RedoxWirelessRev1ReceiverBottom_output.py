from build123d import *
from ocp_vscode import show
import os
import trimesh


# =========================
# SCALE
# =========================

scale = 0.10074


# =========================
# PATH
# =========================

desktop = os.path.expanduser("~/Desktop")

orig_file = os.path.join(
    desktop,
    "RedoxWirelessRev1ReceiverBottom.stl"
)

out_file = os.path.join(
    desktop,
    "RedoxWirelessRev1ReceiverBottom_output.stl"
)


# =========================
# DIMENSIONS
# =========================

L0 = 400
W0 = 260
H0 = 140
T0 = 10

U_width0 = 80
U_depth0 = 80


L = L0 * scale
W = W0 * scale
H = H0 * scale
T = T0 * scale

U_width = U_width0 * scale
U_depth = U_depth0 * scale

wall_height = H - T


# =========================
# MODEL
# =========================

with BuildPart() as part:

    Box(L, W, H)

    with Locations((0, 0, T)):
        Box(
            L - 2*T,
            W - 2*T,
            H - T,
            mode=Mode.SUBTRACT,
        )

    inner_L = L - 2*T
    inner_W = W - 2*T

    zpos = -H/2 + wall_height/2

    with Locations((-inner_L/2 + T/2, 0, zpos)):
        Box(T, inner_W, wall_height)

    with Locations((inner_L/2 - T/2, 0, zpos)):
        Box(T, inner_W, wall_height)

    with Locations((0, -inner_W/2 + T/2, zpos)):
        Box(inner_L, T, wall_height)

    with Locations((0, inner_W/2 - T/2, zpos)):
        Box(inner_L, T, wall_height)


    gz = -H/2 + T/2

    with BuildSketch(Plane.XY.offset(gz)) as sk:

        with BuildLine():

            Line(
                (inner_L/4, -U_width/2),
                (inner_L/4 - U_depth, -U_width/2)
            )

            ThreePointArc(
                (inner_L/4 - U_depth, -U_width/2),
                (inner_L/4 - U_depth - U_width/2, 0),
                (inner_L/4 - U_depth, U_width/2)
            )

            Line(
                (inner_L/4 - U_depth, U_width/2),
                (inner_L/4, U_width/2)
            )

        make_face()

    extrude(
        amount=-T,
        mode=Mode.SUBTRACT,
    )


# =========================
# EXPORT
# =========================

export_stl(part.part, out_file)

print("Saved:", out_file)


# =========================
# VOLUME CHECK
# =========================

def get_volume(path):

    mesh = trimesh.load_mesh(path)

    return mesh.volume


v1 = get_volume(orig_file)
v2 = get_volume(out_file)

diff = abs(v1 - v2)

print("Original volume =", v1)
print("Output volume   =", v2)
print("Difference =", diff)

if v1 != 0:
    print("Percent =", diff / v1 * 100)


show(part.part)