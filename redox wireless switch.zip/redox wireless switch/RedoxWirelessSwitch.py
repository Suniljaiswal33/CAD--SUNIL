from build123d import *

length = 120
width = 50
base_thickness = 10

ramp_height = 40
top_length = 80
top_thickness = 10


with BuildPart() as p:

    with BuildSketch():
        Rectangle(length, width)
    extrude(amount=base_thickness)

    with BuildSketch(Plane.XZ.offset(30)):
        Rectangle(20, ramp_height)
    extrude(amount=width, both=True)

    with BuildSketch(Plane.XZ.offset(30)):
        with BuildLine():
            Polyline(
                (0, 0),
                (top_length, ramp_height),
                (top_length, ramp_height + top_thickness),
                (0, base_thickness),
                close=True,
            )
        make_face()

    extrude(amount=width, both=True)

    with BuildSketch(Plane.XY.offset(ramp_height)):
        Rectangle(top_length, width/2)
    extrude(amount=top_thickness)


export_stl(p.part, "/Users/softage/Desktop/RedoxWirelessSwitch.stl")

print("STL generated on Desktop")